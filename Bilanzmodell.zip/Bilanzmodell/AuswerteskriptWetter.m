
figure(1)
subplot(2,1,1)
plot(No, FF_10, No1, FF_1)
title("Windgeschwindigkeit", "FontSize", 10)
grid on
xlabel('Datenpunkte', "FontSize", 8)
ylabel("v [m/s]", "FontSize", 8)
set(gcf, "Position", [200, 200, 800, 300])
%xlim([0,52560])
ylim([0, 25])


subplot(2,1,2)
plot(No, GS_10, No1, GS_1)
title("Globalstrahlung", "FontSize", 10)
grid on
xlabel('Datenpunkte', "FontSize", 8)
ylabel("E [J/cm²]", "FontSize", 8)
set(gcf, "Position", [200, 200, 800, 300])
%xlim([0,52560])
ylim([0, 100])

%print -depsc Wetter20bis22

figure(2)
plot(LastprofilGesamt)
title("Gesamtlastverlauf", "FontSize", 14)
grid on
xlabel('Messwerte', "FontSize", 12)
ylabel("Leistung [W]", "FontSize", 12)
set(gcf, "Position", [200, 200, 800, 300])
xlim([0,144])
ylim([0, 300])
