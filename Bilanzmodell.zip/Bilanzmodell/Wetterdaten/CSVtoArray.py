import sys  
import os
import pandas as pd

# Open the file
os.chdir(sys.path[0])

results = []
df = pd.read_csv('Weather.csv', delimiter=';', header=0, index_col=0, parse_dates=True, squeeze=True)

# Write Column 5 to array
i = 0

for x in df[df.columns[0]]:
    if i < 3800:
        results.append(x)
    i = i + 1

# Print the array
print(results)

# delete existing file
if os.path.exists('Wind.txt'):
    os.remove('Wind.txt')
f = open('Wind.txt', 'x')
f.write(str(results))
f.close()