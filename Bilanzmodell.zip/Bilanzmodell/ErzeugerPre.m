%clear;

%WaetherData = csvread('Wetterdaten/Weather.csv')

%time=WaetherData(:,1) %assuming first column in csv file is time
%radiation=WaetherData(:,2); % assuming first column in csv file is amplitude corresponding to time
%wind=WaetherData(:,3);

Vrms = 20000 %V
f = 50 %Hz
Tp = 0.1 %s
Tq = 1 %s

hRef = 5 %m
%z0 = 0.5 %Vorstadt
%z0 = 0.03 %Landwirtschaft, leicht hügelig
z0 = 0.0024 %Flughafen
h = 149 %m

Pnom = 3e6
Initial_kWh_pc = 50
LowChrgLim = 10
UpChrgLim = 90
kWh_Rated = 200e3
Efficiency = 90
%Precharge = 

Wirkungsgrad_PV = 0.18

figure(5)
subplot(3,1,1);
plot(pv)
grid on
title("Leistung PV")
xlabel('Zeit in 10-Minuten Intervallen', "FontSize", 10)
ylabel("$P_{PV}~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 600])
xlim([0,52560])

subplot(3,1,2);
plot(wind)
grid on
title("Leistung WEA")
xlabel('Zeit in 10-Minuten Intervallen', "FontSize", 10)
ylabel("$P_{Wind}~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 600])
xlim([0,52560])

subplot(3,1,3);
plot(load)
grid on
title("Leistung Last")
xlabel('Zeit in 10-Minuten Intervallen', "FontSize", 10)
ylabel("$P_{Last}~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 600])
xlim([0,52560])
print -depsc isdq


figure(1)
plot(bilanz)
title("Leistung im Inselnetz ohne Speicher")
grid on
xlabel('Zeit in 10-Minuten Intervallen', "FontSize", 10)
ylabel("$Leistungsbilanz~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 200])
xlim([0,52560])
%ylim([-3e6,3e6])

figure(6)
subplot(2,1,1);
plot(bilanz1)
title("Leistungsbilanz im Inselnetz mit Speicher")
grid on
xlabel('Zeit [s]', "FontSize", 10)
ylabel("$P_{Netz,Sp}~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 400])
xlim([0, 52560])
ylim([-1e6,5e6])

subplot(2,1,2);
plot(soc)
title("SOC Batteriespeicher")
grid on
xlabel('Zeit [s]', "FontSize", 10)
ylabel("$SOC~[\%]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [200, 200, 1200, 400])
xlim([0, 52560])
ylim([10,90])

figure(7)
plot(soc)
title('State of Charge', "FontSize", 10)
grid on
ylim([0, 100])
xlabel('Zeit [s]')
ylabel("$P_{Netz,Sp}~[MW]$", "Interpreter", "latex", "FontSize", 10)
set(gcf, "Position", [100, 100, 1200, 200])
print -depsc n